package cn.zucc.czy.fgo.util;

public class BaseException  extends Exception {
	public BaseException(String msg){
		super(msg);
	}
}
