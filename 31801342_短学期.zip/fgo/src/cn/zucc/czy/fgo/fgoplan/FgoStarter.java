package cn.zucc.czy.fgo.fgoplan;

import cn.zucc.czy.fgo.ui.FrmMain;

public class FgoStarter {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}
}
