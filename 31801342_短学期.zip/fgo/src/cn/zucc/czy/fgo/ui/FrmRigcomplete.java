package cn.zucc.czy.fgo.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.zucc.czy.fgo.control.UserManager;
import cn.zucc.czy.fgo.model.BeanUser;
import cn.zucc.czy.fgo.util.BaseException;



public class FrmRigcomplete extends JDialog implements ActionListener{
    private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	
	private JLabel labelUsername = new JLabel("������");
	private JLabel labelUsersex = new JLabel("�Ա�");
	private JLabel labelUserpho = new JLabel("�绰��");
	private JLabel labelUseremail =new JLabel("���䣺");
	private JLabel labelUsercity =new JLabel("���У�");
	private JLabel labelUserIDcard =new JLabel("֤����:");
	
	private JTextField edtUsername = new JTextField(20);
	private JTextField edtUsersex = new JTextField(20);
	private JTextField edtUserpho = new JTextField(20);
	private JTextField edtUseremail = new JTextField(20);
	private JTextField edtUsercity = new JTextField(20);
	private JTextField edtUserIDcard = new JTextField(20);
	
	
	public FrmRigcomplete(FrmMain f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelUsername);
		workPane.add(edtUsername);
		workPane.add(labelUsersex);
		workPane.add(edtUsersex);
		workPane.add(labelUserpho);
		workPane.add(edtUserpho);
		workPane.add(labelUseremail);
		workPane.add(edtUseremail);
		workPane.add(labelUsercity);
		workPane.add(edtUsercity);
		workPane.add(labelUserIDcard);
		workPane.add(edtUserIDcard);
		
		
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 300);
		// ��Ļ������ʾ
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){
			String username=this.edtUsername.getText();
			String usersex=this.edtUsersex.getText();
			String userpho=this.edtUserpho.getText();
			String useremail=this.edtUseremail.getText();
			String usercity=this.edtUsercity.getText();
			String userIDcard=this.edtUserIDcard.getText();
			
			try {
				(new UserManager()).completeRig(username, usersex, userpho, useremail, usercity, userIDcard,BeanUser.currentLoginUser.getUser_id());
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),"����",JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}
}
