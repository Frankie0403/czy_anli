package cn.zucc.czy.fgo.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


import cn.zucc.czy.fgo.control.EmployeeManager;
import cn.zucc.czy.fgo.control.UserManager;
import cn.zucc.czy.fgo.model.BeanPeople;



public class FrmMain extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JMenuBar menubar=new JMenuBar(); ;
	private JMenu menu_Manager=new JMenu("ϵͳ����");
    private JMenuItem menu_EmployeeManager=new JMenuItem("Ա������");
    private JMenu menu_order=new JMenu("��������");
    private JMenuItem menu_order_add=new JMenuItem("��������");
    private JMenuItem menu_order_delete=new JMenuItem("ɾ������");
    private JMenuItem menu_order_search=new JMenuItem("��������");
    
    
    
    
    private JMenu menu_product=new JMenu("·�߹���");
    private JMenuItem menu_product_add=new JMenuItem("����·��");
    private JMenuItem menu_product_delete=new JMenuItem("ɾ��·��");
    private JMenuItem menu_product_search=new JMenuItem("����·��");
    
    private JMenuItem  menuItem_UserManager=new JMenuItem("�û�����");
    
    
    private JMenu menu_userInfo=new JMenu("�û���Ϣ����");
    private JMenuItem menu_Rig=new JMenuItem("�û���Ϣ����");
    private JMenuItem menu_changePwd=new JMenuItem("�޸�����");
    private JMenuItem  menuItem_VIP=new JMenuItem("vip��ѯ");
    private JMenuItem  menuItem_VIP_add=new JMenuItem("vip��ֵ");

    
    
	private FrmLogin dlgLogin=null;
	private JPanel statusBar = new JPanel();
	public FrmMain(){
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setTitle("FGO----������ϵͳ");
		dlgLogin=new FrmLogin(this,"��½",true);
		dlgLogin.setVisible(true);
	    //�˵�
	    if("Ա��".equals(BeanPeople.currentType.getUser_type())){
	    	menu_Manager.add(menu_EmployeeManager);
	    	menuItem_UserManager.addActionListener(this);
	    	menu_Manager.add(menuItem_UserManager);
	    	menuItem_UserManager.addActionListener(this);
	    	menubar.add(menu_Manager);
	    	
	    	menu_product.add(this.menu_product_add);
	    	menu_product_add.addActionListener(this);
	    	menu_product.add(this.menu_product_delete);
	    	menu_product_delete.addActionListener(this);
	    }else if("�û�".equals(BeanPeople.currentType.getUser_type())) {
	    	menu_userInfo.add(this.menu_Rig);
	    	menu_Rig.addActionListener(this);
	    	menu_userInfo.add(this.menu_changePwd);
	    	menu_changePwd.addActionListener(this);
	    	menu_userInfo.add(this.menuItem_VIP);
	    	menuItem_VIP.addActionListener(this);
	    	menu_userInfo.add(this.menuItem_VIP_add);
	    	menuItem_VIP_add.addActionListener(this);
	    	
	    	menubar.add(menu_userInfo);
	    	
	    }
	    menu_product.add(this.menu_product_search);
	    menu_product_search.addActionListener(this);
	    menubar.add(menu_product);
	    
	    menu_order.add(this.menu_order_add);
	    menu_order_add.addActionListener(this);
	    menu_order.add(this.menu_order_delete);
	    menu_order_delete.addActionListener(this);
	    menu_order.add(this.menu_order_search);
	    menu_order_search.addActionListener(this);
	    
	    menubar.add( menu_order);
	    

	    

	    
	    this.setJMenuBar(menubar);
	    //״̬��
	    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
	    String name=null;
	    if("Ա��".equals(BeanPeople.currentType.getUser_type())) {
	    	name=EmployeeManager.currentEmp.getEmp_name();
	    }else if("�û�".equals(BeanPeople.currentType.getUser_type())) {
	    	name=UserManager.currentUser.getUser_id()+"";
	    }
	    JLabel label=new JLabel("����!"+name);/*vip*/
	    statusBar.add(label);
	    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
	    this.addWindowListener(new WindowAdapter(){   
	    	public void windowClosing(WindowEvent e){ 
	    		System.exit(0);
             }
        });
	    this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.menu_Rig){
			FrmRigcomplete dlg=new FrmRigcomplete(this,"�û���Ϣ����",true);
			dlg.setVisible(true);
		}
	}
	
	
}
