package cn.zucc.czy.fgo.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import cn.zucc.czy.fgo.model.BeanUser;
import cn.zucc.czy.fgo.util.BaseException;
import cn.zucc.czy.fgo.util.BusinessException;
import cn.zucc.czy.fgo.util.DBPool;
import cn.zucc.czy.fgo.util.DbException;



public class UserManager {
	
	
	public BeanUser reg(int userid, String pwd,String pwd2) throws BaseException {
		if("".equals(userid)) throw new BusinessException("�˺Ų���Ϊ��");
		if(pwd==null||"".equals(pwd)) throw new BusinessException("���벻��Ϊ��");
		if(!pwd2.equals(pwd)) throw new BusinessException("�������벻һ��");
		Connection conn=null;
		try {
			conn=DBPool.getInstance().getConnection();
			String sql="select user_id from tbl_user where user_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,userid);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) throw new BusinessException("��½�˺��Ѿ�����");
			rs.close();
			pst.close();
			sql="insert tbl_user(user_id,user_pwd,register_time) VALUES(?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, userid);
			pst.setString(2, pwd);
			pst.setTimestamp(3, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.execute();
			
			BeanUser user=new BeanUser();
			user.setUser_id(userid);
			user.setUser_pwd(pwd);
			user.setRegister_time(new Date());
			
			return user;
		}catch (SQLException e) {
			throw new DbException(e);
		}finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	
	public void completeRig(String name,String sex,String pho,
			String email,String city,String ID_card) throws BaseException{
		if(name==null||"".equals(name)) throw  new BusinessException("��������Ϊ��");
		if(ID_card==null||"".equals(ID_card)) throw new BusinessException("����֤�Ų���Ϊ��");
		
		Connection conn=null;
		try {
			conn=DBPool.getInstance().getConnection();
			String sql="insert into user_info(user_name,user_sex,user_pho,user_email,user_city,user_ID_card) "
					+ "values(?,?,?,?,?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, name);
			pst.setString(2, sex);
			pst.setString(3, pho);
			pst.setString(4, email);
			pst.setString(5, city);
			pst.setString(6, ID_card);
			pst.execute();
			pst.close();
			
			
		}catch (SQLException e) {
			throw new DbException(e);
		}finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	
	public void purchaseVIP() throws BaseException{
		Connection conn=null;
		try {
			conn=DBPool.getInstance().getConnection();
			int user_id=BeanUser.currentLoginUser.getUser_id();
			String sql="insert into user_info(isVIP,VIPdue) values(?,?) where user_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setBoolean(1, true);
			pst.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.setInt(3, user_id);
			/*
			 * ��չ  vip��������
			 * 
			 * */
			
			
			
		}catch (SQLException e) {
			throw new DbException(e);
		}finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
	
	public BeanUser Userlogin(int user_id, String pwd) throws BaseException {
		Connection conn=null;
		BeanUser user=new BeanUser();
		if(user_id+""==null||"".equals(user_id)) throw new BusinessException("�˺Ų���Ϊ��");
		try {
			conn=DBPool.getInstance().getConnection();
			String sql="select user_pwd from user_info where user_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,user_id);
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("��½�˺Ų�����");
			}
			if(pwd==null||"".equals(pwd)) throw new BusinessException("���벻��Ϊ��");
			user.setUser_pwd(pwd);
			user.setUser_id(user_id);
			if(!user.getUser_pwd().equals(rs.getString(1))) throw new BusinessException("�������");
			return user;
		}catch (SQLException e) {
			throw new DbException(e);
		}finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	
	
	
}
