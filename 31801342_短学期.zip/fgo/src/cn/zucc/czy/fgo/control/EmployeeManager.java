package cn.zucc.czy.fgo.control;

import cn.zucc.czy.fgo.model.BeanEmployee;
import cn.zucc.czy.fgo.model.BeanPeople;
import cn.zucc.czy.fgo.model.BeanUser;
import cn.zucc.czy.fgo.util.BaseException;
import cn.zucc.czy.fgo.util.BusinessException;
import cn.zucc.czy.fgo.util.DBPool;
import cn.zucc.czy.fgo.util.DBUtil;
import cn.zucc.czy.fgo.util.DbException;

import java.sql.Connection;
import java.sql.SQLException;

import cn.zucc.czy.fgo.itf.IEmployeeManager;

public class EmployeeManager implements IEmployeeManager{
	public static BeanEmployee currentEmp=null;
	
	public BeanEmployee loadEmp(String emp_id,String pwd) throws BaseException{
		BeanEmployee emp=new BeanEmployee();
		Connection conn=null;
		int empid=Integer.parseInt(emp_id);
		if(emp_id==null||"".equals(emp_id)) throw new BusinessException("�˺Ų���Ϊ��");
		try {
			//conn=DBPool.getInstance().getConnection();
			conn=DBUtil.getConnection();
			String sql="select emp_pwd from manager_info where emp_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,empid);
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("��½�˺Ų�����");
			}
			if(pwd==null||"".equals(pwd)) throw new BusinessException("���벻��Ϊ��");
			if(!pwd.equals(rs.getString(1))) throw new BusinessException("�������");
			
			sql="select emp_name from manager_info where emp_id=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, empid);
			rs=pst.executeQuery();
			rs.next();
			emp.setEmp_pwd(pwd);;
			emp.setEmp_id(empid);
			emp.setEmp_name(rs.getString(1));
			emp.setUser_type("Ա��");
			
			return emp;
		}catch (SQLException e) {
			throw new DbException(e);
		}finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
}
