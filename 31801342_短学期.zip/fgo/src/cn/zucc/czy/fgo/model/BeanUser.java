package cn.zucc.czy.fgo.model;

import java.util.Date;

public class BeanUser{
	public static BeanUser currentLoginUser=null;
	private int user_id;
	private String user_name;
	private String user_sex;
	private String user_pwd;
	private String user_pho;
	private String user_email;
	private String user_city;
	private Date register_time;
	private boolean isVIP;
	private Date VIPdue;
	private String ID_card;
	private String user_type;
	
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public String getUser_pho() {
		return user_pho;
	}
	public void setUser_pho(String user_pho) {
		this.user_pho = user_pho;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_city() {
		return user_city;
	}
	public void setUser_city(String user_city) {
		this.user_city = user_city;
	}
	public Date getRegister_time() {
		return register_time;
	}
	public void setRegister_time(Date register_time) {
		this.register_time = register_time;
	}
	public boolean isVIP() {
		return isVIP;
	}
	public void setVIP(boolean isVIP) {
		this.isVIP = isVIP;
	}
	public Date getVIPdue() {
		return VIPdue;
	}
	public void setVIPdue(Date vIPdue) {
		VIPdue = vIPdue;
	}
	public String getID_card() {
		return ID_card;
	}
	public void setID_card(String iD_card) {
		ID_card = iD_card;
	}
	
	
}
