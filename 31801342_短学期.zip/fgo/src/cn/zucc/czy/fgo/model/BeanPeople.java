package cn.zucc.czy.fgo.model;

public class BeanPeople {
	public static BeanPeople currentType=new BeanPeople();
	
	
	private String user_type;
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
}
