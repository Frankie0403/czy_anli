package cn.zucc.czy.fgo.itf;

import cn.zucc.czy.fgo.model.BeanEmployee;
import cn.zucc.czy.fgo.util.BaseException;

public interface IEmployeeManager {
	public BeanEmployee loadEmp(String user_id,String pwd) throws BaseException;
}
