package cn.zucc.czy.fgo.itf;

import cn.zucc.czy.fgo.model.BeanUser;
import cn.zucc.czy.fgo.util.BaseException;

public interface IUserManager {
	
	public BeanUser reg(String userid, String pwd,String pwd2) throws BaseException;
	
	public void completeRig(String name,String sex,String pho,
			String email,String city,String ID_card,int userid) throws BaseException;
	
	
	public void purchaseVIP() throws BaseException;
	
	
	public BeanUser loadUser(String user_id,String pwd) throws BaseException;
	
	
	
	
	
	
}
