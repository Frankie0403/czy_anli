package cn.edu.zucc.booklib.util;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import java.sql.Connection;

import java.beans.PropertyVetoException;

public class DBUtil2 {
	private static final String jdbcUrl="jdbc:mysql://localhost:3306/booklib";
	private static final String dbUser="root";
	private static final String dbPwd="root";
	
	private static ComboPooledDataSource dataSource;
	static {
		try {
			dataSource = new ComboPooledDataSource();
			dataSource.setUser(dbUser);
			dataSource.setPassword(dbPwd);
			dataSource
					.setJdbcUrl(jdbcUrl);
			dataSource.setDriverClass("com.mysql.jdbc.Driver");
			dataSource.setInitialPoolSize(2);
			dataSource.setMinPoolSize(1);
			dataSource.setMaxPoolSize(15);
			dataSource.setMaxStatements(50);
			dataSource.setMaxIdleTime(60);
		} catch (PropertyVetoException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static Connection getConnection() throws java.sql.SQLException{
		return dataSource.getConnection();
	}
	
}
