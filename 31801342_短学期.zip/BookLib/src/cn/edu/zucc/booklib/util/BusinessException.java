package cn.edu.zucc.booklib.util;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
