package cn.edu.zucc.booklib;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import cn.edu.zucc.booklib.control.BookLendManager;
import cn.edu.zucc.booklib.control.BookManager;
import cn.edu.zucc.booklib.control.OrdersManager;
import cn.edu.zucc.booklib.control.ProductsManager;
import cn.edu.zucc.booklib.control.PublisherManager;
import cn.edu.zucc.booklib.control.ReaderManager;
import cn.edu.zucc.booklib.model.BeanBook;
import cn.edu.zucc.booklib.model.BeanPublisher;
import cn.edu.zucc.booklib.model.BeanReader;
import cn.edu.zucc.booklib.model.Orders;
import cn.edu.zucc.booklib.model.Products;
import cn.edu.zucc.booklib.util.BaseException;
import cn.edu.zucc.booklib.control.SystemUserManager;


public class testMain {

	public static void main(String[] args) throws BaseException, ParseException {
		// TODO Auto-generated method stub
		//(new BookLendManager()).showAllLendRecord();
		//(new BookManager()).showTop5Books();
		//(new BookManager()).showTop5Publisher();
		
//		System.out.printf("���������Աid��");
//		String userid=input.nextLine();
//		System.out.printf("��������ĺ�Ĺ���Ա���֣�");
//		String username=input.nextLine();
		
//		(new BookLendManager()).printDateLendRecord("2020-05-22 11:39:39");
//		Products p = new Products();
//		p.setProductID(2);
//		p.setProductName("צ");
//		p.setUnitPrice(100);
//		p.setUnitsInStock(200);
//		
//		
//		(new ProductsManager()).modifyProducts(p);
/*����1000
		BeanReader br=new BeanReader();
		int i;
		int limit = 0;
		Integer start=31801366;
		for(i=1;i<=1000;i++) {
			start=start+1;
			br.setReaderid(start.toString());
			br.setReaderName((new ranName()).getName());
			br.setReaderTypeId(i%4);
			switch(i%4) {
			 case 1:limit=5;break;
			 case 2:limit=2;break;
			 case 3:limit=3;break;
			 case 4:limit=1;break;
			}
			br.setLendBookLimitted(limit);
			br.setCreateDate(new java.sql.Timestamp(System.currentTimeMillis()));
		}
*/
//		System.out.println((new ranName()).getName());
        
/*���ߵ���	
		ReaderManager rm = new ReaderManager();
		BeanReader r = new BeanReader();
		System.out.print("����Ҫ��ѯ�Ķ���ID:");
		String readerID=input.nextLine();
		r=rm.loadReader(readerID);
		int i=0;
		System.out.println("����ID��"+r.getReaderid());
		System.out.println("����������"+r.getReaderName());
		System.out.println("�������"+r.getReaderTypeName());
		System.out.println("�������ƣ�"+r.getLendBookLimitted());
		System.out.println("�������ڣ�"+r.getCreateDate());
		System.out.println("���ļ�¼");
		for(BeanBook b:r.getList()) {
			i++;
			System.out.println("No."+i+" Barcode:"+b.getBarcode()+" BookName:"+b.getBookname()+" pubid:"+b.getPubid()+" price:"
					+b.getPrice()+" state:"+b.getState());
		}
*/
		String d="2019-3-26 23:06:29";
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=formatter.parse(d);
		
		Scanner input = new Scanner(System.in);
		System.out.print("����Ҫ��ѯ�Ķ���:");
		String cid=input.next();
		List<Orders> list=(new OrdersManager()).searchOrdersByCID(cid);
		

		if(list.isEmpty()) System.out.println("�޴�ID");
		else {
			for(Orders o: list) {
				System.out.println("OrderID:"+o.getOrderID());
				System.out.println("CustomerID:"+o.getCustomerID());
				System.out.println("EmployeeID:"+o.getEmployeeID());
				System.out.println("OrderDate:"+o.getOrderDate());
			}
		}
		
		
		input.close();
		
		
		
		
		
		

	}

}
