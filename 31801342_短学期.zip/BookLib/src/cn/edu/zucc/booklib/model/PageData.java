package cn.edu.zucc.booklib.model;

import java.util.List;

public class PageData {
	private int totalRecordCount;
	private int pageCount;
	private int pagesize;
	private int pageIndex;
	private List<BeanReader> beanReader;
	public final int getTotalRecordCount() {
		return totalRecordCount;
	}
	public final void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}
	public final int getPageCount() {
		return pageCount;
	}
	public final void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public final int getPagesize() {
		return pagesize;
	}
	public final void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	
	public final int getPageIndex() {
		return pageIndex;
	}
	public final void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}
	public final List<BeanReader> getData() {
		return beanReader;
	}
	public final void setData(List<BeanReader> beanReader) {
		this.beanReader = beanReader;
	}
}
