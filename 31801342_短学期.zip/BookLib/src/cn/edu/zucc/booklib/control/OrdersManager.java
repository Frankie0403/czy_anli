package cn.edu.zucc.booklib.control;

import java.sql.Connection;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.booklib.model.Orders;
import cn.edu.zucc.booklib.util.BaseException;
import cn.edu.zucc.booklib.util.BusinessException;
import cn.edu.zucc.booklib.util.DBUtil;
import cn.edu.zucc.booklib.util.DBUtil2;
import cn.edu.zucc.booklib.util.DbException;

public class OrdersManager {
	
	
	public void addOrders (Orders ord)throws BaseException{
		if((ord.getCustomerID()).equals(null)||ord.getOrderID()==0||ord.getEmployeeID()==0||(ord.getOrderDate()).equals(null)) {
			throw new BusinessException("��������");
		}
		Connection conn=null;
		try {
			conn=DBUtil2.getConnection();
			
			String sql="select OrderID from orders where OrderID = ?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,ord.getOrderID());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) throw new BusinessException("�Ѵ����ظ�id");
			
			sql="insert into orders(OrderID,CustomerID,EmployeeID,OrderDate) values(?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1, ord.getOrderID());
			pst.setString(2, ord.getCustomerID());
			pst.setInt(3, ord.getEmployeeID());
			pst.setDate(4, (java.sql.Date) ord.getOrderDate());
			pst.execute();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public List<Orders> searchOrdersByCID(String cid) throws BaseException{
		Connection conn=null;
		List<Orders> list=new ArrayList<Orders>();
		try {
			conn=DBUtil.getConnection();
			String sql="select OrderID,CustomerID,EmployeeID,OrderID from orders where CustomerID = ?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,cid);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				Orders p =new Orders();
				p.setOrderID(rs.getInt(1));
				p.setCustomerID(rs.getString(2));
				p.setEmployeeID(rs.getInt(3));
				p.setOrderDate(rs.getDate(4));
				list.add(p);
			}
			return list;
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}
		
		
		
		
		
	
	
	
	
	
	
