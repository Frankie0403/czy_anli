package cn.edu.zucc.booklib.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.edu.zucc.booklib.model.BeanvieworderDetail;
import cn.edu.zucc.booklib.util.BaseException;
import cn.edu.zucc.booklib.util.DBUtil;
import cn.edu.zucc.booklib.util.DbException;

public class ViewOrdersManager {
	public List<BeanvieworderDetail> orderQuery2 (int orderid)throws BaseException{
		List<BeanvieworderDetail> l = new ArrayList<BeanvieworderDetail>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select OrderID,ProductName,Quantity,UnitPrice,OrderDate from viewOrderDetail where "
					+ "OrderID=?";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, orderid);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanvieworderDetail t=new BeanvieworderDetail();
				t.setOrderID(rs.getInt(1));
				t.setProductName(rs.getString(2));
				t.setQuantity(rs.getInt(3));
				t.setUnitPrice(rs.getDouble(4));
				t.setOrderDate(rs.getTimestamp(5));
				l.add(t);
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		return l;
	}
	
	public Map<String,Double> getProductTotalFee(String productName)throws BaseException{
		Map<String,Double> m = new HashMap<String,Double>();
		Connection conn=null;
		try {
			double sum;
			conn=DBUtil.getConnection();
			String sql="select ProductName,Quantity,UnitPrice from viewOrderDetail where ProductName "
					+ "like '"+productName+"'";
			java.sql.Statement st =conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			
			while(rs.next()) {
				BeanvieworderDetail t=new BeanvieworderDetail();
				t.setProductName(rs.getString(1));
				t.setQuantity(rs.getInt(2));
				t.setUnitPrice(rs.getDouble(3));
				sum=t.getUnitPrice()*t.getQuantity();
				m.put(t.getProductName(), sum);
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return m;

	}
	public List<String> getMaxOrderedProductName()throws BaseException{
		List<String> list = new ArrayList<String>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select ProductName from viewOrderDetail where Quantity "
					+ "= (select max(Quantity) from viewOrderDetail) as a";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				list.add(rs.getString(1));
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return list;
		
	}
	
	
}
