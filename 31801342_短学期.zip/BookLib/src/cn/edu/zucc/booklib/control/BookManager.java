package cn.edu.zucc.booklib.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.booklib.model.BeanBook;
import cn.edu.zucc.booklib.util.BaseException;
import cn.edu.zucc.booklib.util.BusinessException;
import cn.edu.zucc.booklib.util.DBUtil;
import cn.edu.zucc.booklib.util.DBUtil2;
import cn.edu.zucc.booklib.util.DbException;

public class BookManager {
	public List<BeanBook> searchBook(String keyword,String bookState)throws BaseException{
		List<BeanBook> result=new ArrayList<BeanBook>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select b.barcode,b.bookname,b.pubid,b.price,b.state,p.publishername " +
					" from beanbook b left outer join beanpublisher p on (b.pubid=p.pubid)" +
					" where  b.state='"+bookState+"' ";
			if(keyword!=null && !"".equals(keyword))
				sql+=" and (b.bookname like ? or b.barcode like ?)";
			sql+=" order by b.barcode";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			if(keyword!=null && !"".equals(keyword)){
				pst.setString(1, "%"+keyword+"%");
				pst.setString(2, "%"+keyword+"%");
				
			}
				
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanBook b=new BeanBook();
				b.setBarcode(rs.getString(1));
				b.setBookname(rs.getString(2));
				b.setPubid(rs.getString(3));
				b.setPrice(rs.getDouble(4));
				b.setState(rs.getString(5));
				b.setPubName(rs.getString(6));
				result.add(b);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
		
	}
	public static  void createBook(BeanBook b) throws BaseException{
		
		
		if(b.getBarcode()==null || "".equals(b.getBarcode()) || b.getBarcode().length()>20){
			throw new BusinessException("���������1-20����");
		}
		if(b.getBookname()==null || "".equals(b.getBookname()) || b.getBookname().length()>50){
			throw new BusinessException("ͼ�����Ʊ�����1-50����");
		}
		Connection conn=null;
		try {
			conn=DBUtil2.getConnection();
			String sql="select * from BeanBook where barcode=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, b.getBarcode());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) throw new BusinessException("�����Ѿ���ռ��");
			rs.close();
			pst.close();
			sql="insert into BeanBook(barcode,bookname,pubid,price,state) values(?,?,?,?,'�ڿ�')";
			pst=conn.prepareStatement(sql);
			pst.setString(1, b.getBarcode());
			pst.setString(2, b.getBookname());
			pst.setString(3, b.getPubid());
			pst.setDouble(4, b.getPrice());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
	public void modifyBook(BeanBook b) throws BaseException{
		if(b.getBookname()==null || "".equals(b.getBookname()) || b.getBookname().length()>50){
			throw new BusinessException("ͼ�����Ʊ�����1-50����");
		}
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from BeanBook where barcode=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, b.getBarcode());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("ͼ�鲻����");
			rs.close();
			pst.close();
			sql="update BeanBook set bookname=?,pubid=?,price=?,state=? where barcode=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,b.getBookname());
			pst.setString(2, b.getPubid());
			pst.setDouble(3,b.getPrice());
			pst.setString(4, b.getState());
			pst.setString(5, b.getBarcode());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public BeanBook loadBook(String barcode) throws DbException {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select b.barcode,b.bookname,b.pubid,b.price,b.state,p.publishername " +
					" from beanbook b left outer join beanpublisher p on (b.pubid=p.pubid)" +
					" where  b.barcode=? ";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,barcode);	
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()){
				BeanBook b=new BeanBook();
				b.setBarcode(rs.getString(1));
				b.setBookname(rs.getString(2));
				b.setPubid(rs.getString(3));
				b.setPrice(rs.getDouble(4));
				b.setState(rs.getString(5));
				b.setPubName(rs.getString(6));
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}
	
	public int getBookCount(String pubid) throws BaseException{
		if(pubid==null || "".equals(pubid) ||pubid.length()>20){
			throw new BusinessException("�������ű�����1-20����");
		}
		int num = 0;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select count(bookname) from (\r\n" + 
					"select distinct bookname from beanbook where pubid=?"+") as a;";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,pubid);	
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				num=rs.getInt(1);
			}
			return num;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public int getPublisherCount() throws BaseException{
		int num=0;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select count(distinct pubid) from Beanbook";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) {
				num=rs.getInt(1);
			}
			return num;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public int getNoneBookPublisherCount()throws BaseException{
		int num=0;
		int Num=0;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select Count(*) from beanbook";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) {
				Num=rs.getInt(1);
			}
			
			if(Num==0) {
				throw new BusinessException("�������޵Ǽǵĳ�����");
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		try {
			conn=DBUtil.getConnection();
			String sql="select count(distinct pubid) from beanpublisher\r\n" + 
					"where pubid not in (\r\n" + 
					"select distinct beanpublisher.pubid from beanbook inner join beanpublisher on beanbook.pubid=beanpublisher.pubid) \r\n" + 
					"";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) {
				num=rs.getInt(1);
			}
			return num;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public double getBookAvgPrice()throws BaseException{
		int num=0;
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select Count(*) from beanbook";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) {
				num=rs.getInt(1);
			}
			if(num==0) {
				throw new BusinessException("��������ͼ��");
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		
		
		double AvgPri=0;
		try {
			conn=DBUtil.getConnection();
			String sql="select Avg(price) from beanbook";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()) {
				AvgPri=rs.getInt(1);
			}
			return AvgPri;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void showTop5Books() throws BaseException {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select bookname,count(*) 'sum' from beanbook as bb INNER JOIN beanbooklendrecord as blr\r\n" + 
					"on bb.barcode=blr.bookBarcode GROUP BY blr.bookBarcode ORDER BY sum desc LIMIT 5";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+'\t'+rs.getInt(2));
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	
	public void showTop5Publisher() throws BaseException {
		Connection conn=null;
		
		try {
			conn=DBUtil.getConnection();
			String sql="select distinct publisherName,count(publisherName) from beanbook as bb INNER JOIN beanbooklendrecord as blr\r\n" + 
					"on bb.barcode=blr.bookBarcode INNER JOIN beanpublisher as bp on bb.pubid=bp.pubid group by publisherName\r\n" + 
					"ORDER BY count(publisherName) desc limit 5";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+'\t'+rs.getInt(2));
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
	}
	
	
	public static void main(String[] arg) {
		try {
			long start=System.currentTimeMillis();
			for(int i=1000;i<2000;i++){
				BeanBook b=new BeanBook();
				b.setBarcode(2000+i+"");
				b.setBookname("ˮ��"+i+"");
				b.setPrice(10.0);
				b.setPubid("001");
				createBook(b);
			}
			long end=System.currentTimeMillis();
			System.out.println("��ǰ�����ʱ��"+(end-start)+"ms");
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	
}
