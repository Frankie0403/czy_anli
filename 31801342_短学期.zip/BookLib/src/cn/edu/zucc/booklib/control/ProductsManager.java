package cn.edu.zucc.booklib.control;

import java.sql.Connection;
import java.sql.SQLException;


import cn.edu.zucc.booklib.model.Products;
import cn.edu.zucc.booklib.util.BaseException;
import cn.edu.zucc.booklib.util.BusinessException;
import cn.edu.zucc.booklib.util.DBUtil;
import cn.edu.zucc.booklib.util.DbException;

public class ProductsManager {
	public void modifyProducts (Products p)throws BaseException{
		if((p.getProductName()).equals(null)||p.getProductID()==0||p.getUnitPrice()==0||p.getUnitsInStock()==0) {
			throw new BusinessException("�������");
		}
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select UnitPrice from products where ProductId = ?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, p.getProductID());
//			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�޴�id");
			
			sql="update products set ProductName=?,UnitPrice=?,UnitsInStock=? where ProductId=?";
//			sql="update products set ProductName = '"+p.getProductName()+"'"+",UnitPrice = "+p.getUnitPrice()+",UnitsInStock = "+p.getUnitsInStock()+" where ProductId = "+p.getProductID();
			pst=conn.prepareStatement(sql);
			pst.setString(1, p.getProductName());
			pst.setDouble(2, p.getUnitPrice());
			pst.setInt(3, p.getUnitsInStock());
			pst.setInt(4, p.getProductID());
//			if(st.execute(sql)) System.out.println("�޸ĳɹ�");
			if(pst.execute()) System.out.println("�޸ĳɹ�");
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
	}



	
	
}
