package cn.edu.zucc.personplan.util;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
