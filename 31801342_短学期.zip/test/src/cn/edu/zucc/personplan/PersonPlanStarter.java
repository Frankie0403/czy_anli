package cn.edu.zucc.personplan;

import cn.edu.zucc.personplan.ui.FrmMain;

public class PersonPlanStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
